//
//  SecondViewController.swift
//  NavigationControllerTask
//
//  Created by Razan alshatti on 29/02/2024.
//

import UIKit

class SecondViewController: UIViewController {
    
    var recievedData: String?
    
    var nameLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .cyan
        title = "Details View"
        view.addSubview(nameLabel)
        
        print(recievedData ?? "No data recieved")
        
        setupAutoLayout()
        // Do any additional setup after loading the view.
        
    }
    

    
    // MARK: - Navigation
    
    func setupAutoLayout(){
        nameLabel.snp.makeConstraints { make in
            make.center.equalToSuperview()
        }
    }


}
