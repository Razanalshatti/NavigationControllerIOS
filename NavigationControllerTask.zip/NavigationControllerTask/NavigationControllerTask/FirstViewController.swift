//
//  ViewController.swift
//  NavigationControllerTask
//
//  Created by Razan alshatti on 29/02/2024.
//

import UIKit
import SnapKit

class FirstViewController: UIViewController {
    
    let navigationButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white // set background color
        
        view.addSubview(navigationButton)
        title = "First Page"
        
        setupUI()
        setupAutoLayout()
        setupNavigationBar()

        // add tartget action for button
        navigationButton.addTarget(self, action: #selector(navigationButtonTapped), for:.touchUpInside )
        // Do any additional setup after loading the view.
    }
    
    @objc func navigationButtonTapped() {
        print("Button Tapped 🛡️")

        // Navigation Code
        let secondVC = SecondViewController()
        secondVC.recievedData = "Message recieved"
        self.navigationController?.pushViewController(secondVC, animated: true)
        secondVC.nameLabel.text = "Welcome to details view 📥 !! "

    }
    
    func setupUI(){
        //setup navigationButton properties
        navigationButton.setTitle("Show Details", for: .normal)
        navigationButton.backgroundColor = .systemGray
        navigationButton.layer.cornerRadius = 10
    }
    
    func setupAutoLayout(){
        navigationButton.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
    }
    func setupNavigationBar(){
        let appearance = UINavigationBarAppearance()
        appearance.configureWithDefaultBackground()
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
    }



}

